module.exports = {
	/**
	 * @type {string}
	 * @description 首页三张背景图
	 */
	bg1: 'https://cdn.auhuy.top/blog/img/bg1.jpg',
	bg2: 'https://cdn.auhuy.top/blog/img/bg2.jpg',
	bg3: 'https://cdn.auhuy.top/blog/img/bg3.jpg',

	/**
	 * @type {string}
	 * @description 首页故障风文字
	 */
	malfunctionText: 'auhuy\'s Blog'
}
