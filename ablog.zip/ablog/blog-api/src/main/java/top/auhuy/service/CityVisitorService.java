package top.auhuy.service;

import top.auhuy.entity.CityVisitor;

public interface CityVisitorService {
	void saveCityVisitor(CityVisitor cityVisitor);
}
