module.exports = {
  presets: [ [ '@vue/app', { useBuiltIns: 'entry' } ] ]
  // presets: [
  //   '@vue/cli-plugin-babel/preset'
  // ]
}
