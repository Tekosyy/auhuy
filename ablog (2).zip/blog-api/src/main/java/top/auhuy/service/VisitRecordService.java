package top.auhuy.service;

import top.auhuy.entity.VisitRecord;

public interface VisitRecordService {
	void saveVisitRecord(VisitRecord visitRecord);
}
